﻿using _3wheel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _3wheel.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        [NonAction]
        public static List<Class1> GetEmployeeList()
        {
            return new List<Class1>{
      new Class1{
         AadharNumber = 1,
         Name = "Abhi",
         Email = "abhi@gmail.com",
         DOB = DateTime.Parse(DateTime.Today.ToString()),
         Amount = 23,
         Home = "Delhi",
      },

      new Class1{
         AadharNumber = 2,
         Name = "pushkin",
         Email = "pushkin@gmail.com",
         DOB = DateTime.Parse(DateTime.Today.ToString()),
         Amount = 45,
         Home = "Mumbai",
      },

      new Class1{
         AadharNumber= 3,
         Name = "ram",
         Email = "ram@gmail.com",
         DOB = DateTime.Parse(DateTime.Today.ToString()),
         Amount = 37,
         Home = "Kolkata",
      },

      new Class1{
         AadharNumber = 4,
         Name = "sing",
         Email = "sing@gmail.com",
         DOB = DateTime.Parse(DateTime.Today.ToString()),
         Amount = 26,
         Home = "Chennai",
      },
   };
        }
        public ActionResult Index()
        {
            var employees = from e in GetEmployeeList()
                            orderby e.AadharNumber
                            select e;
            return View(employees);
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
