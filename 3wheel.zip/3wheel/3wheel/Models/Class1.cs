﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _3wheel.Models
{
    public class Class1
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime DOB { get; set; }
        public int AadharNumber { get; set; }
        public string Home { get; set; }
        public float Amount { get; set; }  
    }
}